import React from 'react';
import { 
  Home, 
  Upload, 
  Download, 
  History, 
  BarChart3, 
  Users, 
  Settings,
  FileText
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange }) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';

  const menuItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: Home },
    { id: 'files', label: 'Mes fichiers', icon: FileText },
    { id: 'upload', label: 'Upload', icon: Upload },
    { id: 'history', label: 'Historique', icon: History },
    { id: 'reports', label: 'Rapports', icon: BarChart3 },
    ...(isAdmin ? [
      { id: 'users', label: 'Utilisateurs', icon: Users },
      { id: 'global-reports', label: 'Rapports globaux', icon: BarChart3 },
      { id: 'settings', label: 'Paramètres', icon: Settings }
    ] : [])
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-800">FileManager</h2>
        <p className="text-sm text-gray-600 mt-1">
          {isAdmin ? 'Administration' : 'Espace utilisateur'}
        </p>
      </div>
      
      <nav className="p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onTabChange(item.id)}
                  className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;