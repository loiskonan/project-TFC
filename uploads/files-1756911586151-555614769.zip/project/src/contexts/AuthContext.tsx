import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  currentUser: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>({
    id: '1',
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'admin',
    createdAt: '2024-01-01',
    lastLoginAt: '2024-12-20',
    isActive: true
  });
  const [isLoading, setIsLoading] = useState(false);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    // Simulation d'authentification
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email === 'admin@example.com') {
      setCurrentUser({
        id: '1',
        email: 'admin@example.com',
        name: 'Admin User',
        role: 'admin',
        createdAt: '2024-01-01',
        lastLoginAt: new Date().toISOString(),
        isActive: true
      });
    } else {
      setCurrentUser({
        id: '2',
        email: 'user@example.com',
        name: 'Regular User',
        role: 'user',
        createdAt: '2024-01-15',
        lastLoginAt: new Date().toISOString(),
        isActive: true
      });
    }
    setIsLoading(false);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};